<template>
    <div>
      <h1>这是下载页面</h1>
    </div>
</template>

<script>
export default {
  name: 'download'
}
</script>

<style scoped>

</style>
