<template>
    <div>
      <h1>查看详情</h1>
    </div>
</template>

<script>
export default {
  name: 'detail'
}
</script>

<style scoped>

</style>
