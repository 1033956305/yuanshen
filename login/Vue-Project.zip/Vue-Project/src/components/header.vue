<template>
  <h1>头部</h1>
</template>

<script>
export default {
  name: 'headerDiv'
}
</script>

<style scoped>

</style>
